$('.cookie__close').on('click', function(e) {
    e.preventDefault();
    $('.cookie').hide();
})