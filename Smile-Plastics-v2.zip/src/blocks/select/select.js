import 'select2';
let selectElement = $('.select-main');

if (selectElement.length) {
    selectElement.select2({
        minimumResultsForSearch: -1,
        dropdownCssClass: "sort-drop",
        containerCssClass: "sort-select",
    });
}