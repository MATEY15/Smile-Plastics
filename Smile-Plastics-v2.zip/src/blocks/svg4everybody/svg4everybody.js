import svg4everybody from 'svg4everybody/dist/svg4everybody.legacy.js';

svg4everybody({
    // nosvg: true,
    polyfill: true
});